
import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { collection, query, where, getDocs } from "firebase/firestore";
import { db } from "../firebase";
import BusCard from "../components/BusCard";

export default function SearchResults() {
  const [params] = useSearchParams();
  const [buses, setBuses] = useState([]);

  useEffect(() => {
    const load = async () => {
      const q = query(
        collection(db, "buses"),
        where("from", "==", params.get("from")),
        where("to", "==", params.get("to"))
      );
      const snap = await getDocs(q);
      setBuses(snap.docs.map(d=>({...d.data(), id:d.id})));
    };
    load();
  }, []);

  return (
    <div style={{padding:'20px'}}>
      <h2>Results</h2>
      {buses.map(bus => <BusCard bus={bus} key={bus.id} />)}
    </div>
  );
}
