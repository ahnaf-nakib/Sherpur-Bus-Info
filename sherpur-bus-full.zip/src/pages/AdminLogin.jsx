
export default function AdminLogin() {
  return <div style={{padding:'20px'}}><h2>Admin Login (Simple Static)</h2></div>;
}
