
import { useEffect, useState } from "react";
import { collection, getDocs, addDoc, deleteDoc, doc } from "firebase/firestore";
import { db } from "../firebase";

export default function AdminPending() {
  const [list, setList] = useState([]);

  useEffect(()=>{
    const load = async () => {
      const snap = await getDocs(collection(db, "buses_request"));
      setList(snap.docs.map(d=>({id:d.id,...d.data()})));
    };
    load();
  },[]);

  const approve = async (item) => {
    await addDoc(collection(db,"buses"), item);
    await deleteDoc(doc(db,"buses_request", item.id));
    alert("Approved");
  };

  return (
    <div style={{padding:'20px'}}>
      <h2>Pending Requests</h2>
      {list.map(i=>(
        <div key={i.id} style={{padding:'10px', background:'white', marginBottom:'10px'}}>
          <p>{i.name}</p>
          <button onClick={()=>approve(i)}>Approve</button>
        </div>
      ))}
    </div>
  );
}
