
import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Home() {
  const nav = useNavigate();
  const [from, setFrom] = useState("Sherpur");
  const [to, setTo] = useState("Dhaka");
  const [time, setTime] = useState("");

  return (
    <div style={{padding:'20px'}}>
      <h2>Search Bus</h2>

      <div>
        <input placeholder="From" value={from} onChange={e=>setFrom(e.target.value)} />
        <input placeholder="To" value={to} onChange={e=>setTo(e.target.value)} />
        <select onChange={e=>setTime(e.target.value)}>
          <option value="">Any Time</option>
          <option value="morning">Morning</option>
          <option value="evening">Evening</option>
        </select>

        <button onClick={()=>nav(`/search?from=${from}&to=${to}&time=${time}`)}>
          Search
        </button>
      </div>
    </div>
  );
}
