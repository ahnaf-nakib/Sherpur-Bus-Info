
import { useState } from "react";
import { collection, addDoc } from "firebase/firestore";
import { db } from "../firebase";

export default function SubmitBus() {
  const [form, setForm] = useState({ name:"", from:"", to:"", time:"", phone:"" });

  const submit = async () => {
    await addDoc(collection(db, "buses_request"), form);
    alert("Submitted for admin approval!");
  };

  return (
    <div style={{padding:'20px'}}>
      <h2>Submit Your Bus Info</h2>
      <input placeholder="Bus Name" onChange={e=>setForm({...form, name:e.target.value})}/>
      <input placeholder="From" onChange={e=>setForm({...form, from:e.target.value})}/>
      <input placeholder="To" onChange={e=>setForm({...form, to:e.target.value})}/>
      <input placeholder="Time" onChange={e=>setForm({...form, time:e.target.value})}/>
      <input placeholder="Phone" onChange={e=>setForm({...form, phone:e.target.value})}/>
      <button onClick={submit}>Submit</button>
    </div>
  );
}
