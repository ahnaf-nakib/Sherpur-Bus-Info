
import { Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import SearchResults from "./pages/SearchResults";
import SubmitBus from "./pages/SubmitBus";
import AdminLogin from "./pages/AdminLogin";
import AdminPending from "./pages/AdminPending";
import Navbar from "./components/Navbar";

export default function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/search" element={<SearchResults />} />
        <Route path="/submit" element={<SubmitBus />} />
        <Route path="/admin" element={<AdminLogin />} />
        <Route path="/admin/pending" element={<AdminPending />} />
      </Routes>
    </>
  );
}
