
import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav style={{padding:'15px', background:'#2563EB', color:'white'}}>
      <Link to="/" style={{color:'white', textDecoration:'none', fontSize:'20px'}}>Sherpur Bus Info</Link>
    </nav>
  );
}
