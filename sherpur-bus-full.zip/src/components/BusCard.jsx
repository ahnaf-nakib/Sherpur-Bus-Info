
export default function BusCard({ bus }) {
  return (
    <div style={{
      background:'white',
      padding:'15px',
      borderRadius:'12px',
      marginBottom:'12px',
      boxShadow:'0 2px 5px rgba(0,0,0,0.1)'
    }}>
      <h3>{bus.name}</h3>
      <p>From: {bus.from} → To: {bus.to}</p>
      <p>Time: {bus.time}</p>
      <p>Contact: {bus.phone}</p>
      <a href={"tel:"+bus.phone}>
        <button style={{marginTop:'8px'}}>Call Now</button>
      </a>
    </div>
  );
}
